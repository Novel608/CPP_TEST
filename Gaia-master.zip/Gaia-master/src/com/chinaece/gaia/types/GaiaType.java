package com.chinaece.gaia.types;

public interface GaiaType {

}
