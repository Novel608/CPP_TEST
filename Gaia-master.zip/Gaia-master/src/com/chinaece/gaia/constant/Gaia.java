package com.chinaece.gaia.constant;

import java.util.Collection;

import com.chinaece.gaia.types.AppType;

public class Gaia {
	public static final String TAG_HTTP = "http api";
	public static final String TAG_JSON = "json";
	
	public static boolean DEBUG = true;
	
	public static Collection<AppType> APPLIST;
}
