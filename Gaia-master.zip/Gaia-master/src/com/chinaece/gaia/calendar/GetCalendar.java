package com.chinaece.gaia.calendar;


public interface GetCalendar {
	public void getCalendar(String startTime, String endTime);
}
