package com.chinaece.gaia.util;

public class VersionInfo {

	private String versionCode;
	private String url;
	private String changelog;

	public String getVersionCode() {
		return versionCode;
	}

	public void setVersionCode(String versionCode) {
		this.versionCode = versionCode;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getChangelog() {
		return changelog;
	}

	public void setchangelog(String changelog) {
		this.changelog = changelog;
	}

}
